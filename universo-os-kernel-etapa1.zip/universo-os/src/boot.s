/* Multiboot v1 entry point */
.set MAGIC, 0x1BADB002
.set FLAGS, 0x00000007
.set CHECKSUM, -(MAGIC + FLAGS)
.section .multiboot
.align 4
.long MAGIC, FLAGS, CHECKSUM
/* Multiboot v1 reserves the five address fields even when flag 16 is clear. */
.long 0, 0, 0, 0, 0
/* Video request: common linear graphics mode, 800x600x32 */
.long 0, 800, 600, 32
.section .bss
.align 16
stack_bottom:
.skip 16384
stack_top:
.section .text
.global _start
.type _start,@function
_start:
    cli
    cld
    mov $stack_top, %esp
    push %ebx
    push %eax
    call kernel_main
halt:
    hlt
    jmp halt
