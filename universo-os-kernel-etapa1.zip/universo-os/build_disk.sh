#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v mkfs.fat >/dev/null || { echo 'Falta dosfstools (mkfs.fat).' >&2; exit 1; }
command -v mcopy >/dev/null || { echo 'Falta mtools (mcopy).' >&2; exit 1; }
mkdir -p build
img=build/universo-disk.img
size=$((64*1024*1024))
sectors=$((size/512))
start=2048
count=$((sectors-start))
truncate -s "$size" "$img"
python3 - "$img" "$start" "$count" <<'PY'
import struct,sys
path,start,count=sys.argv[1],int(sys.argv[2]),int(sys.argv[3])
with open(path,'r+b') as f:
    m=bytearray(512)
    p=bytearray(16)
    p[1:4]=b'\x00\x02\x00'
    p[4]=0x06                 # FAT16
    p[5:8]=b'\xfe\xff\xff'
    struct.pack_into('<II',p,8,start,count)
    m[446:462]=p
    m[510:512]=b'\x55\xaa'
    f.seek(0);f.write(m)
PY
mkfs.fat -F 16 --offset="$start" -n UNIVDATA "$img" "$((count/2))" >/dev/null
offset=$((start*512))
mcopy -o -i "$img@@$offset" apps/examples/hola-mundo.univ ::HOLA.UNI
mcopy -o -i "$img@@$offset" apps/examples/calculadora.univ ::CALC.UNI
mcopy -o -i "$img@@$offset" apps/examples/tareas.univ ::TAREAS.UNI
printf 'Disco listo: %s (%s MiB, MBR/FAT16, solo lectura desde el kernel)\n' "$PWD/$img" "$((size/1024/1024))"
