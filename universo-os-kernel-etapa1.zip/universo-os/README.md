# Universo OS — kernel x86 educativo

Universo OS es un prototipo de sistema operativo con kernel propio de 32 bits, escrito en C++ freestanding y ensamblador x86, con arranque GRUB/Multiboot. Esta versión incorpora el primer hito de almacenamiento y se ha probado en QEMU; no es todavía un sistema operativo de uso diario.

## Arranque y escritorio

La ISO inicia en la bienvenida; el escritorio experimental incluye menú Inicio, barra de tareas, ventanas para Archivos, Terminal, Configuración y Aplicaciones. El renderizador usa un búfer de pantalla y restaura solo la región del cursor al moverlo, para evitar el parpadeo. La firma visible es **Creado por Alejandro Eng 2026**.

En QEMU, `F1` abre el escritorio. La tecla `1` abre Archivos, `2` Terminal, `3` Configuración y `4` Aplicaciones. `Esc` vuelve. El ratón PS/2 permite mover el cursor y hacer clic.

## Disco y sistema de archivos — primera etapa

El kernel sondea el **disco maestro IDE primario con ATA PIO**, lee la tabla de particiones MBR y monta en solo lectura la primera partición primaria FAT16 reconocida (tipos MBR `0x04`, `0x06` o `0x0E`). El explorador enumera las entradas de la raíz FAT16; los paquetes `.univ` compatibles se pueden leer y lanzar desde el disco. El ejecutor sigue siendo un microintérprete limitado a líneas `print("texto")`, no es CPython.

Para mantener seguro el prototipo, el kernel no escribe sectores, no crea ni modifica particiones y solo lee nombres 8.3 de la raíz. En esta etapa no admite directorios FAT, nombres largos VFAT, FAT32/NTFS/ext4, discos SATA/AHCI, NVMe ni VirtIO; tampoco hay instalación persistente. El instalador de la interfaz sigue siendo una vista previa y no toca unidades.

`build.sh` genera la ISO y, si están instalados `dosfstools` y `mtools`, genera también `build/universo-disk.img`: un disco virtual MBR/FAT16 de 64 MiB con `HOLA.UNI`, `CALC.UNI` y `TAREAS.UNI`. Ese archivo es solo una imagen de prueba, no un disco físico.

Arranque recomendado en QEMU, con la imagen virtual adjunta como disco IDE maestro:

```bash
qemu-system-i386 -m 256M -vga std \
  -cdrom build/universo-os-x86.iso \
  -drive file=build/universo-disk.img,format=raw,if=ide,index=0 \
  -boot d
```

Desde el escritorio, abre **Archivos → Disco FAT16**, selecciona `HOLA.UNI` y pulsa **Ejecutar app**. La salida de Hola Mundo aparece en la ficha del archivo. Se ha validado este recorrido completo en QEMU con la imagen adjunta.

## Apps `.univ`

Los paquetes incluidos pueden cargarse como módulos de GRUB o desde la raíz FAT16 del disco de demostración. Por seguridad, no se ejecuta código Python arbitrario: solo se aceptan instrucciones `print("literal")`. `Hola Mundo` funciona con este subconjunto; Calculadora y Tareas aún usan construcciones no implementadas. `univctl.py` valida y copia paquetes al staging del anfitrión, no instala software de forma persistente dentro del kernel.

## Compilar

En Linux se requieren el compilador cruzado x86 (`i686-linux-gnu-gcc` y `i686-linux-gnu-g++`), binutils, GRUB BIOS y `xorriso`. Para generar también el disco de demostración instala `dosfstools` y `mtools`.

```bash
./build.sh
```

La ISO resultante es `build/universo-os-x86.iso`; el disco de prueba es `build/universo-disk.img`. También se puede regenerar solo el disco con `./build_disk.sh`.

## Estado y trabajo pendiente

Implementado: kernel x86 Multiboot, framebuffer con fallback VGA, interfaz/cursor PS/2, teclado básico, lector ATA PIO para IDE primario, MBR y FAT16 de solo lectura, explorador de archivos raíz y microintérprete de paquetes muy reducido.

Pendiente: escritura segura y particionado, sistema de archivos completo con directorios y nombres largos, soporte de múltiples controladores y buses (SATA/AHCI, NVMe, USB y VirtIO), memoria virtual y procesos aislados, CPython/JVM, terminal real, red Ethernet, TCP/IP, DHCP, DNS, TLS/certificados, Wi‑Fi, Bluetooth y un navegador web. Por ello esta ISO todavía no puede abrir `google.com` ni utilizarse para instalar o guardar datos importantes.
