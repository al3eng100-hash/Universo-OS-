#!/usr/bin/env python3
"""Prototipo de staging .univ en el host; no forma parte del kernel."""
import argparse, json, re, sys
from pathlib import Path

ROOT = Path.home() / ".universo" / "apps"
NAME = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9 _.-]{0,47}$")

def parse(path):
    raw = path.read_text(encoding="utf-8")
    header, sep, payload = raw.partition("--- main.py ---\n")
    if not sep:
        raise ValueError("falta la sección --- main.py ---")
    meta = {}
    for line in header.splitlines():
        if "=" in line:
            k, v = line.split("=", 1); meta[k.strip()] = v.strip()
    if not header.startswith("UNIV-PACKAGE/1"):
        raise ValueError("versión de paquete no soportada")
    for key in ("name", "version", "architecture"):
        if not meta.get(key): raise ValueError(f"falta metadato {key}")
    if not NAME.fullmatch(meta["name"]): raise ValueError("nombre no permitido")
    if meta["architecture"] not in ("x86", "any"): raise ValueError("arquitectura incompatible")
    if not payload.strip(): raise ValueError("el paquete no contiene main.py")
    return meta, payload

def main():
    ap = argparse.ArgumentParser(description="Gestor experimental de paquetes Universo .univ")
    sub = ap.add_subparsers(dest="cmd", required=True)
    ins = sub.add_parser("install", help="instalar paquete en el staging del usuario")
    ins.add_argument("package", type=Path)
    sub.add_parser("list", help="listar paquetes instalados")
    args = ap.parse_args()
    try:
        if args.cmd == "install":
            meta, payload = parse(args.package)
            ROOT.mkdir(parents=True, exist_ok=True)
            dest = ROOT / (meta["name"].lower().replace(" ", "-") + "-" + meta["version"])
            dest.mkdir(exist_ok=True)
            (dest / "manifest.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
            (dest / "main.py").write_text(payload, encoding="utf-8")
            print(f"Paquete preparado en {dest}. No se ejecutó código.")
        else:
            if ROOT.exists():
                for f in sorted(ROOT.glob("*/manifest.json")):
                    m = json.loads(f.read_text(encoding="utf-8")); print(f"{m['name']} {m['version']} ({m['architecture']})")
    except (OSError, ValueError) as e:
        print(f"univctl: {e}", file=sys.stderr); return 1
    return 0

if __name__ == "__main__": raise SystemExit(main())
