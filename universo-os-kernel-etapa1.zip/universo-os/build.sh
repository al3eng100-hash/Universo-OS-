#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
CXX=${CXX:-i686-linux-gnu-g++}
CC=${CC:-i686-linux-gnu-gcc}
LD=${LD:-i686-linux-gnu-ld}
mkdir -p build/iso/boot/grub build/iso/apps/examples
$CC -m32 -c src/boot.s -o build/boot.o
$CXX -m32 -std=c++17 -O2 -ffreestanding -fno-exceptions -fno-rtti -fno-stack-protector -fno-pic -fno-pie -fno-use-cxa-atexit -Wall -Wextra -c src/kernel.cpp -o build/kernel.o
$LD -m elf_i386 -T linker.ld -nostdlib build/boot.o build/kernel.o -o build/kernel.elf
if ! grub-file --is-x86-multiboot build/kernel.elf; then echo 'Error: el kernel no pasa la comprobacion Multiboot.' >&2; exit 1; fi
cp build/kernel.elf build/iso/boot/kernel.elf
cp boot/grub.cfg build/iso/boot/grub/grub.cfg
cp apps/examples/*.univ build/iso/apps/examples/
if ! command -v grub-mkrescue >/dev/null || [ ! -d /usr/lib/grub/i386-pc ]; then
  echo 'Kernel x86 compilado en build/kernel.elf; falta GRUB BIOS (grub-pc-bin) para producir ISO arrancable.' >&2
  exit 2
fi
grub-mkrescue -o build/universo-os-x86.iso build/iso
printf '\nISO lista: %s/build/universo-os-x86.iso\n' "$PWD"
if command -v mkfs.fat >/dev/null && command -v mcopy >/dev/null; then
  ./build_disk.sh
else
  echo 'Disco de prueba opcional: instala dosfstools y mtools, luego ejecuta ./build_disk.sh.'
fi
